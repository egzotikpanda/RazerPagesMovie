﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RazorPagesMovie.Web.UI.Data;
using RazorPagesMovie.Web.UI.Data.Models;

namespace RazorPagesMovie.Web.UI.Pages.Movies
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Movie> Movies { get; set; }
        public SelectList Genres { get; set; }

        [BindProperty(SupportsGet = true)]
        public string Q { get; set; }

        /// <summary>
        /// Selected genre for movie filtering
        /// </summary>
        [BindProperty(SupportsGet = true)]
        public string G { get; set; }

        public async Task OnGetAsync()
        {
            var genres = await _context.Movies
                                .Select(x => x.Genre)
                                .Distinct()
                                .OrderBy(x=> x)
                                .ToArrayAsync();

            var movies = _context.Movies.AsQueryable();

            if (!string.IsNullOrWhiteSpace(Q))
                movies = movies.Where(x => x.Title.Contains(Q));

            if (!string.IsNullOrWhiteSpace(G))
                movies = movies.Where(x => x.Genre == G);

            Genres = new SelectList(genres);
            Movies = await movies.ToListAsync();
        }
    }
}
