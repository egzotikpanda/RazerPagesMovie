﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RazorPagesMovie.Web.UI.Data.Migrations
{
    public partial class AddedRatingToMovies : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Rating",
                table: "Movies",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Rating",
                table: "Movies");
        }
    }
}
