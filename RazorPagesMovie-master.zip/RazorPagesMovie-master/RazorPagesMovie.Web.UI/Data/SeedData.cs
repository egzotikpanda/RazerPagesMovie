﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RazorPagesMovie.Web.UI.Data.Models;
using System;
using System.Linq;

namespace RazorPagesMovie.Web.UI.Data
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDbContext(serviceProvider.GetService<DbContextOptions<ApplicationDbContext>>()))
            {
                if (context.Movies.Any())
                    return;

                context.Movies.AddRange(
                    new Movie
                    {
                        Title = "Gold",
                        ReleaseDate = new DateTime(2016, 1, 1),
                        Genre = "Drama"
                    },
                    new Movie
                    {
                        Title = "The Wolf of Wall Street",
                        ReleaseDate = new DateTime(2013, 1, 1),
                        Genre = "Drama"
                    },
                    new Movie
                    {
                        Title = "Departed",
                        ReleaseDate = new DateTime(2006, 1, 1),
                        Genre = "Crime"
                    },
                    new Movie
                    {
                        Title = "Dolamite is my Name",
                        ReleaseDate = new DateTime(2019, 1, 1),
                        Genre = "True Story"
                    });

                context.SaveChanges();
            }
        }
    }
}
